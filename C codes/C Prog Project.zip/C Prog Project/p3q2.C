#include<stdio.h>
void main()
{
clrscr();
printf("Maths = 90\nPhysics = 77\nChemistry = 69");
getch();
}
