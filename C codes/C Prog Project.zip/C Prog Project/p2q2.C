#include<stdio.h>
void main()
{
clrscr();
printf("Name : Ritik\nDob : 18/12/2004\nAddress : New Delhi-110075, India");
getch();
}
