#include<stdio.h>
void main(){
int i;
clrscr();
printf("\n  First 10 Natural Numbers:\n");
  for(i=1;i<=10;i++)
  printf("%d  ",i);
getch();
}
