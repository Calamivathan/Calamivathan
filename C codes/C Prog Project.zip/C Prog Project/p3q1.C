#include<stdio.h>
void main()
{
clrscr();
printf("1992\t17421\n1993\t29210\n1994\t100523");
getch();
}
