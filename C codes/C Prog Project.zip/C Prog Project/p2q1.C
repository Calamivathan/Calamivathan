#include<stdio.h>
void main()
{
clrscr();
printf("\nHello");
getch();
}
